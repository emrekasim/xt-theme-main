$(document).ready(function () {
    // Carousel Home Page
    var owl = $('.owl-carousel');
    owl.owlCarousel({
        loop: true,
        nav: false,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        margin:10,
        responsiveClass:true,
        responsive:{
            0:{
                items:1,
                nav:true,
                autoWidth: true,
                margin:15,
            },
            1000:{
                items:2,
                nav:true,
                loop:false
            },
            1440:{
                items:3,
                nav:true,
                loop:false
            }
        }
    });
    $(".owl-carousel .owl-next").hide();
    $(".owl-carousel .owl-prev").hide();

    // Add Attr For input Search

    var inputSearch = $('.bs-searchbox input');
    inputSearch.attr('placeholder', 'search');

    // Start Cuont Down
    $('#clock').countdown('2023/10/10', function(event) {
        $(this).html(event.strftime('%D %H:%M:%S'));
    });

    // Toggle Between Usd Number And Stars
    $('#toggle-usdstar').click(function(){
        if ($('#profitstar, #vlauestar').hasClass('d-inline-block') && $('#profitnum, #vlauenum').hasClass('d-none')) {
            $('#profitstar, #vlauestar').removeClass('d-inline-block').addClass('d-none');
            $('#profitnum, #vlauenum').removeClass('d-none').addClass('d-inline-block');
        } else {
            $('#profitstar, #vlauestar').removeClass('d-none').addClass('d-inline-block');
            $('#profitnum, #vlauenum').removeClass('d-inline-block').addClass('d-none');
        }
    });

    // Toggle Between Deposit Address And Network
    $('#cointype').change(function(){
        $('#deposit-address').removeClass('d-inline-block').addClass('d-none');
        $('#network').removeClass('d-none').addClass('d-inline-block');
        $("select option[value='selectNetwork']").attr("selected","selected");
    });

    // Toggle Between Network And Deposit Address
    $('#networkType').change(function(){
        $('#network').removeClass('d-inline-block').addClass('d-none');
        $('#deposit-address').removeClass('d-none').addClass('d-inline-block');
        $("select option[value='selectNetwork']").removeAttr("selected");
    });

    // Add Class To Table History
    $('.staking-history-content .fixed-table-container').addClass('bg-white p-4');
    // Add Style To Table History
    $('.staking-history-content .fixed-table-container').css('border-radius', '8px');
    $('.staking-history-content .fixed-table-body').css('height', '70%');

    // Add Button Inside Address Select

    //apply bootstrap selectpicker
    $("#address ul.dropdown-menu").append(`<li class="selected active">
    <a role="option" class="dropdown-item " id="bs-select-3-0" tabindex="0" aria-setsize="1" aria-posinset="1" aria-selected="true">
    <button type="button" class="btn p-0 font-s12 fw-bolder" data-bs-toggle="modal"
    data-bs-target="#addressModal"><i class="fa-solid fa-plus me-1"></i>Add Address</button></a></li>`)
    
});