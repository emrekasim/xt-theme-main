<footer>
    <div class="app-footer pt-2 pt-md-4">
        <div class="footer-container container">
            <div class="row">
                <div class="d-none d-md-block col-md-3">
                    <img src="resources/images/ecotx-logo.png" alt="footer-logo">
                    <p>© 2022 XT.COM</p>
                    <p>The World’s First Social Infused Exchange</p>
                </div>
                <div class="col-md-9">
                    <div class="row">
                        <div class="col-md-3">
                            <a class="btn btn-link d-flex d-md-none px-0 justify-content-between" data-bs-toggle="collapse" href="#technical-sup" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                                <h6 class="d-inline-block me-1">Technical Support</h6>
                                <i class="fa-solid fa-sort-down"></i>
                            </a>
                            <div class="d-md-block collapse multi-collapse" id="technical-sup">
                                <h6 class="d-none d-md-block">Technical Support</h6>
                                <ul>
                                    <li>
                                        <a href="">APP Download</a>
                                    </li>
                                    <li>
                                        <a href="">API Documentation</a>
                                    </li>
                                    <li>
                                        <a href="">FAQ</a>
                                    </li>
                                    <li>
                                        <a href="">Submit A Ticket</a>
                                    </li>
                                    <li>
                                        <a href="">Clear Cache</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-link d-flex d-md-none px-0 justify-content-between" data-bs-toggle="collapse" href="#about-us" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                                <h6 class="d-inline-block me-1">About Us</h6>
                                <i class="fa-solid fa-sort-down"></i>
                            </a>
                            <div class="d-md-block collapse multi-collapse" id="about-us">
                                <h6 class="d-none d-md-block">About Us</h6>
                                <ul>
                                    <li>
                                        <a href="">About XT.com</a>
                                    </li>
                                    <li>
                                        <a href="">Join us</a>
                                    </li>
                                    <li>
                                        <a href="">Announcement</a>
                                    </li>
                                    <li>
                                        <a href="">Fee</a>
                                    </li>
                                    <li>
                                        <a href="">Asset Intro</a>
                                    </li>
                                    <li>
                                        <a href="">Schedule</a>
                                    </li>
                                    <li>
                                        <a href="">XT Media Toolkit</a>
                                    </li>
                                    <li>
                                        <a href="">Official verification channel</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-link d-flex d-md-none px-0 justify-content-between" data-bs-toggle="collapse" href="#terms" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                                <h6 class="d-inline-block me-1">Terms</h6>
                                <i class="fa-solid fa-sort-down"></i>
                            </a>
                            <div class="d-md-block collapse multi-collapse" id="terms">
                                <h6 class="d-none d-md-block">Terms</h6>
                                <ul>
                                    <li>
                                        <a href="">Privacy</a>
                                    </li>
                                    <li>
                                        <a href="">User Agreement</a>
                                    </li>
                                    <li>
                                        <a href="">Law Enforcement Requests</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <a class="btn btn-link d-flex d-md-none px-0 justify-content-between" data-bs-toggle="collapse" href="#contact-us" role="button" aria-expanded="false" aria-controls="multiCollapseExample1">
                                <h6 class="d-inline-block me-1">Contact Us</h6>
                                <i class="fa-solid fa-sort-down"></i>
                            </a>
                            <div class="d-md-block collapse multi-collapse" id="contact-us">
                                <h6 class="d-inline-block me-1">Contact Us</h6>
                                <div class="footer-social">
                                    <img src="" alt="">
                                </div>
                                <ul>
                                    <li>
                                        <a href="">Customer Support: support@xt.com</a>
                                    </li>
                                    <li>
                                        <a href="">Listing Application: listing@xt.com</a>
                                    </li>
                                    <li>
                                        <a href="">Business Cooperation: business@xt.com</a>
                                    </li>
                                    <li>
                                        <a href="">IDO/IGO Application: xtstarter@xt.com</a>
                                    </li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
                <hr>
                <div class="col-md-1">
                    <p>Partners</p>
                </div>
                <div class="col-md-11">

                </div>
            </div>
        </div>
    </div>
</footer>

<script src="resources/js/jquery-3.6.0.min.js"></script>
<script src="resources/js/bootstrap.bundle.js"></script>
<script src="resources/js/bootstrap-select.min.js"></script>
<script src="resources/js/owl.carousel.min.js"></script>
<script src="resources/js/bootstrap-table.min.js"></script>
<script src="resources/js/bootstrap-select-country.min.js"></script>
<script src="resources/js/jquery.countdown.min.js"></script>
<script src="resources/js/chart.min.js"></script>
<script src="resources/js/index.js"></script>
