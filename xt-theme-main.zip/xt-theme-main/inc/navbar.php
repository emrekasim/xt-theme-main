<nav class="navbar navbar-expand-lg navbar-dark nav-pages fixed-top">
    <div class="container-fluid">
        <a class="navbar-brand pe-sm-0" href="#">
            <img src="resources/images/ecotx-logo.png" alt="ecotx-logo">
        </a>
        <div class="">

        </div>
        <button class="navbar-toggler" type="button" data-bs-toggle="offcanvas" data-bs-target="#navbarOffcanvasLg" aria-controls="navbarOffcanvasLg">
            <span class="navbar-toggler-icon"></span>
        </button>
        <div class="offcanvas offcanvas-end bg-dark bg-lg-transparent" tabindex="-1" id="navbarOffcanvasLg" aria-labelledby="navbarOffcanvasLgLabel">
            <div class="row w-100">
                <div class="col-12 d-lg-none my-4 px-0 login-mobile">
                    <div class="px-0 me-md-1 mb-3 main-btn btn btn-outline-warning">
                        <a href="" class="text-decoration-none main-color btn">Login</a>
                    </div>
                    <div class="px-0 main-btn bgx-main">
                        <a href="" class="btn">Sign up</a>
                    </div>
                </div>
                <div class="col-12 col-lg-8 px-0 menu-group">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown d-none d-lg-inline-block">
                            <a class="nav-link" href="#" id="main-drop" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fa-solid fa-bars"></i>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="main-drop">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/monitoring.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Exchange</p>
                                                <div>Digital Asset Trading Platform</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/cute-rocket-launching.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">ECOXT Starter</p>
                                                <div>Token Offering Platform</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/flask.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Labs</p>
                                                <div>Blockchain Research & Investment</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/squares.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Academy</p>
                                                <div>Blockchain and crypto education</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/link.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">ECOTX Smart Chain</p>
                                                <div>Decentralized, highly efficient public chain</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/users.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Invitation to rebate</p>
                                                <div>Invite friends to enjoy 40% rebate</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/calendar.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Schedule</p>
                                                <div>Latest platform activities and information</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="#">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-chart-column d-inline-block d-lg-none main-color"></i>
                                    <span>Markets</span>
                                </div>
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-bullseye d-inline-block d-lg-none main-color"></i>
                                    <span>Trading</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Standard Spot</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Cryptocurrency trading, 800+ market trading pairs</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Pro Spot</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Cryptocurrency trading, 800+ market trading pairs</p>
                                    </a>
                                    
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Standard Margin</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Cryptocurrency trading, 800+ market trading pairs</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Pro Margin</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Cryptocurrency trading, 800+ market trading pairs</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-tv d-inline-block d-lg-none main-color"></i>
                                    <span>Derivatives</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">USD-M Futures</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Perpetual contract specified in the settlement currency USDT</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">USD-M Futures(Demo)</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Participate in simulated futures trading and share the 200,000USDT prize pool</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Coin-M Futures</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Perpetual contract paid with cryptocurrency</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Quanto Futures</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Perpetual contract paid with cryptocurrency</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Standard ETF</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Unsecured assets, zero liquidation risk</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Pro ETF</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Unsecured assets, zero liquidation risk</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">ETF Ranking</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Full screen ETF trading</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">ETF Index</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Track multiple digital assets, diversify investment risk</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-circle-dollar-to-slot d-inline-block d-lg-none main-color"></i>
                                    <span>Buy Crypto</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Third-party payment</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Buy cryptocurrency using Visa or Mastercard, etc.</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">P2P Trading</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Buy USDT or cryptocurrency using your bank card</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-brands fa-bitcoin d-inline-block d-lg-none main-color"></i>
                                    <span>Finance</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Savings</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Free deposit and fixed deposit options available</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Staking</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Stake and get great rewards</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Staking</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Stake and get great rewards</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Staking</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Stake and get great rewards</p>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <p class="text-white font-s14 mb-0">Staking</p>
                                        <p class="font-s12 d-none d-lg-block gray-color-semi mb-0">Stake and get great rewards</p>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="col-12 col-lg-9 px-0 menu-group d-lg-none">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="main-drop" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-square-poll-horizontal d-inline-block d-lg-none main-color"></i>
                                    <span>More</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="main-drop">
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/monitoring.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Exchange</p>
                                                <div>Digital Asset Trading Platform</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/cute-rocket-launching.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">ECOXT Starter</p>
                                                <div>Token Offering Platform</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/flask.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Labs</p>
                                                <div>Blockchain Research & Investment</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/squares.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Academy</p>
                                                <div>Blockchain and crypto education</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/link.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">ECOTX Smart Chain</p>
                                                <div>Decentralized, highly efficient public chain</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/users.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Invitation to rebate</p>
                                                <div>Invite friends to enjoy 40% rebate</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                                <li>
                                    <a class="dropdown-item" href="#">
                                        <div class="main-dropdown">
                                            <div class="img-pic me-2">
                                                <img src="resources/images/icons/calendar.svg" alt="">
                                            </div>
                                            <div class="text-pic">
                                                <p class="mb-0">Schedule</p>
                                                <div>Latest platform activities and information</div>
                                            </div>
                                        </div>
                                    </a>
                                </li>
                            </ul>
                        </li>
                    </ul>
                </div>
                <div class="nvabar-right col-12 col-lg-4 d-flex justify-lg-content-end px-0 px-md-3 menu-group">
                    <div class="row text-lg-center align-items-center flex-wrap flex-lg-nowrap w-100">
                        <div class="col-lg-2 px-0 me-md-1 d-none d-lg-inline-block">
                            <a href="">Login</a>
                        </div>
                        <div class="col-lg-3 px-0 main-btn d-none d-lg-inline-block">
                            <a href="">Sign up</a>
                        </div>
                        <div class="col-lg-3 px-0">
                            <a href="">
                                <div class="d-inline-block">
                                    <i class="fa-solid fa-cloud-arrow-down d-inline-block d-lg-none main-color"></i>
                                    <span>Download</span>
                                </div>
                            </a>
                        </div>
                        <div class="col-lg-4 px-0 position-relative">
                            <a class="nav-link dropdown-toggle px-0" href="#" id="navbarDropdown" role="button"
                                data-bs-toggle="dropdown" aria-expanded="false">
                                <div class="d-inline-block">
                                    <i class="fa-brands fa-gg-circle d-inline-block d-lg-none main-color"></i>
                                    <span>English/USD</span>
                                </div>
                            </a>
                            <ul class="dropdown-menu" aria-labelledby="navbarDropdown">
                                <li>
                                    <a class="dropdown-item font-s14 gray-color-lite" href="#">English</a>
                                </li>
                                <li>
                                    <a class="dropdown-item font-s14 gray-color-lite" href="#">Español</a>
                                </li>
                            </ul>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</nav>